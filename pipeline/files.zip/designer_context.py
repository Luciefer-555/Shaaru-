"""
pipeline/extractors/prompts/designer_context.py

Builds the designer-aware context block injected at the TOP
of every vision prompt before any analysis begins.

This is the single most important hallucination prevention mechanism.
The model must know WHICH designer it is analyzing before it looks
at the image — otherwise it applies generic fashion knowledge
that may be completely wrong for this designer's aesthetic.
"""

import json
import os
from typing import Optional


def load_quality_gates(config_path: str = None) -> list:
    if config_path is None:
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "..", "config", "quality_gates.json"
        )
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_designer_context_block(
    designer_config: dict,
    gates: list,
    product_metadata: Optional[dict] = None
) -> str:
    """
    Builds the calibration block injected at the top of every vision prompt.

    designer_config: from designers.json
        {id, name, aesthetic_hint, region, platform}
    gates: loaded quality_gates list
    product_metadata: optional parsed product page data
        (confirmed fabrics, techniques from text)

    Returns a formatted string block ready to prepend to any vision prompt.
    """
    designer_id = designer_config.get("id", "")
    designer_name = designer_config.get("name", "")
    aesthetic_hint = designer_config.get("aesthetic_hint", "")
    region = designer_config.get("region", "")

    gate = next((g for g in gates if g["designer_id"] == designer_id), None)

    # Build product-level ground truth section
    product_truth = ""
    if product_metadata:
        fabric_map = product_metadata.get("fabric_map", {})
        techniques = product_metadata.get("techniques", [])
        color = product_metadata.get("color_name", "")
        components = product_metadata.get("component_count")

        if fabric_map or techniques or color:
            product_truth = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRODUCT PAGE GROUND TRUTH
(confirmed by the brand — highest authority)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
            if fabric_map:
                product_truth += "Fabrics confirmed by brand:\n"
                for component, fabric in fabric_map.items():
                    product_truth += f"  {component}: {fabric}\n"

            if techniques:
                product_truth += f"Techniques confirmed by brand:\n"
                for t in techniques:
                    product_truth += f"  - {t}\n"

            if color:
                product_truth += f"Color confirmed by brand: {color}\n"

            if components:
                product_truth += f"Number of components: {components}\n"

            product_truth += """
INSTRUCTION: If the brand confirmed a fabric for a component,
use that fabric for that component. Observe its visual properties.
Do NOT substitute a different fabric even if you think it looks different.
If the brand named something vague like "Special Silk" that is NOT
in our database — flag it as new_fabric_candidate and describe
what you actually see visually.
"""

    # Build must-not-appear warning block
    hallucination_guard = ""
    if gate and gate.get("must_not_appear"):
        banned = gate["must_not_appear"]
        hallucination_guard = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HALLUCINATION GUARD — CRITICAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
The following terms MUST NOT appear in your output for {designer_name}.
This designer is NOT known for these — if you think you see them,
you are very likely hallucinating. Stop and look again carefully:

  {chr(10).join(f"  ✗ {term}" for term in banned)}

If you still believe one of these is genuinely present after
looking carefully — report it with confidence: "uncertain"
and explain your visual evidence in confidence_notes.
Never report them as "confirmed".
"""

    # Build expected findings block
    expected_block = ""
    if gate:
        fabrics = gate.get("primary_fabrics", [])
        techniques = gate.get("primary_techniques", [])

        if fabrics or techniques:
            expected_block = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXPECTED FINDINGS FOR {designer_name.upper()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This designer is known to work with:

"""
            if fabrics:
                expected_block += "  Common fabrics:\n"
                for f in fabrics:
                    expected_block += f"    - {f}\n"

            if techniques:
                expected_block += "  Common techniques:\n"
                for t in techniques:
                    expected_block += f"    - {t}\n"

            if gate.get("must_appear_in_candidates"):
                expected_block += """
  ⚠️  SPECIAL RULE FOR THIS DESIGNER:
  This designer uses experimental textiles NOT in the standard DB.
  All fabrics should come back as new_fabric_candidates.
  Describe what you see precisely. Do not match to standard fabric IDs.
"""

            expected_block += """
  These are CALIBRATION GUIDES — not permissions to ignore visual evidence.
  If you genuinely see something unexpected, report it honestly.
"""

    # Build designer notes
    notes = ""
    if gate and gate.get("notes"):
        notes = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ANALYST NOTES FOR {designer_name.upper()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{gate['notes']}
"""

    # Assemble full block
    context_block = f"""
╔══════════════════════════════════════════════════════════════╗
  DESIGNER CONTEXT — READ BEFORE ANALYZING THE IMAGE
╚══════════════════════════════════════════════════════════════╝

Designer:   {designer_name}
Region:     {region}
Aesthetic:  {aesthetic_hint}
{product_truth}
{hallucination_guard}
{expected_block}
{notes}
╔══════════════════════════════════════════════════════════════╗
  END OF DESIGNER CONTEXT — NOW ANALYZE THE IMAGE
╚══════════════════════════════════════════════════════════════╝
"""
    return context_block


def build_fabric_colour_prompt_with_context(
    anchor_block: str,
    designer_config: dict,
    gates: list,
    product_metadata: Optional[dict] = None
) -> str:
    """
    Fabric/colour focused prompt with designer context prepended.
    Replaces the generic build_fabric_colour_prompt().
    """
    context = build_designer_context_block(designer_config, gates, product_metadata)

    return f"""{context}

{anchor_block}

You are analyzing ONLY fabric, colour, weave structure, and surface pattern.
Do not comment on silhouette, garment type, or embellishment placement.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FABRIC IDENTIFICATION RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For each visible fabric:
1. Check the DESIGNER CONTEXT above first
2. Check the GROUND TRUTH section — if brand confirmed a fabric, use it
3. If brand said something vague (Special Silk, Premium Fabric etc)
   and that string is not in our fabric database → new_candidate = true
4. NULL IS ALWAYS BETTER THAN WRONG

Fabric confirmation visual tests:
  velvet        → dense pile, depth of colour, soft matte sheen
  organza       → MUST see crisp stiff MESH STRUCTURE — not just transparent
  net/tulle     → MUST see hexagonal mesh — not just sheer
  katan_silk    → smooth, heavy drape, consistent sheen, no texture variation
  raw_silk_dupion → IRREGULAR SLUBS visible on surface
  handloom_cotton → slight roughness, natural irregularity in weave
  pure_linen    → dry texture, creases visible, natural fibre gaps
  georgette     → crinkled surface, very fluid, lightweight
  banarasi_silk → heavy brocade with WOVEN motifs (not printed, not embroidered)
  wire/mesh     → metallic, structured, industrial — does NOT flow like fabric

Surface pattern ONLY if genuinely present as print or woven pattern:
  block_print   → slight variation between repeats, hand-pressed quality
  digital_print → photographic precision, perfect gradients
  screen_print  → consistent flat colour, sharp edges
  woven_jacquard → pattern IS the weave structure, not applied on top
  ikat          → blurred edges where resist-dyed threads meet

Return ONLY valid JSON. Start with {{ end with }}.
No markdown. No preamble.

{{
  "fabrics": [
    {{
      "component": "",
      "fabric_id_guess": "",
      "is_new_candidate": false,
      "new_candidate_description": "",
      "weave_structure": "",
      "surface_texture": "",
      "sheen_level": "high|medium|low|none",
      "opacity": "opaque|semi-sheer|sheer",
      "drape_observation": "",
      "drape_score_estimate": 0,
      "weight_estimate": "light|medium|heavy",
      "seasonal_read": "summer|winter|transitional|all-year",
      "confidence": "confirmed|probable|uncertain"
    }}
  ],
  "color_intelligence": {{
    "color_name_from_image": "",
    "color_family": "pastel|earth|jewel|neutral|dark|bright",
    "temperature": "warm|cool|neutral",
    "metallic_accent": "gold|silver|rose-gold|none",
    "contrast_level": "high|medium|low",
    "color_notes": ""
  }},
  "surface_patterns": {{
    "has_surface_print": false,
    "print_method": null,
    "motif_type": null,
    "motif_placement": null,
    "pattern_comes_from_embellishment_not_print": false
  }}
}}
"""


def build_structure_embellishment_prompt_with_context(
    anchor_block: str,
    designer_config: dict,
    gates: list,
    product_metadata: Optional[dict] = None
) -> str:
    """
    Structure/embellishment focused prompt with designer context prepended.
    Replaces the generic build_structure_embellishment_prompt().
    """
    context = build_designer_context_block(designer_config, gates, product_metadata)
    designer_id = designer_config.get("id", "")
    gate = next((g for g in gates if g["designer_id"] == designer_id), None)

    # Build technique-specific rules based on designer
    technique_rules = ""
    if gate:
        must_not = gate.get("must_not_appear", [])
        primary_techniques = gate.get("primary_techniques", [])

        if "mirror work" in must_not or "sheesha" in must_not:
            technique_rules = """
MIRROR WORK RULE FOR THIS DESIGNER:
This designer does NOT typically use mirror work.
If you think you see mirrors, look again — it may be:
  - sequins (flat, plastic/metallic disc)
  - foil print (surface applied, not sewn)
  - surface sheen from the fabric itself
Only report mirror work if you can clearly see individual circular glass pieces.
"""
        elif "sheesha_mirror" in primary_techniques:
            technique_rules = """
MIRROR WORK RULE FOR THIS DESIGNER:
This designer IS known for sheesha mirror work.
If mirrors are present, identify the scatter pattern precisely:
  "constellation" = irregular random scatter, NO GRID — like stars
  "jaal"          = dense regular grid mesh — clear repeat unit
  "boota"         = isolated motif islands with space between
  "border"        = mirrors at hem/cuffs/neckline only
  "all-over"      = even coverage, no directional logic
Look carefully at SPACING before deciding.
Also identify the connecting thread — is it resham (coloured silk) 
or zari (metallic)?
"""

        if "zardozi" in must_not:
            technique_rules += """
ZARDOZI RULE FOR THIS DESIGNER:
This designer does NOT use zardozi.
Do not report zardozi even if you see metallic embroidery.
Metallic thread on this designer is most likely:
  - zari_flat (flat metallic thread, woven or stitched flat)
  - resham_thread (silk thread, may have subtle sheen)
"""
        elif "zardozi_thread_gold" in primary_techniques:
            technique_rules += """
ZARDOZI IDENTIFICATION:
This designer DOES use zardozi. Confirm by:
  - Visible gold metal wire (not thread — wire)
  - 3D raised effect from the surface
  - Heavy, sculptural quality
  - Deep jewel-tone palette context
Resham is NOT zardozi. Flat zari is NOT zardozi.
"""

    return f"""{context}

{anchor_block}

You are analyzing ONLY garment structure, silhouette, and embellishment.
Do not comment on fabric type, colour, or drape.

{technique_rules}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EMBELLISHMENT RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ONLY report embellishments you can genuinely confirm visually.
Common confusions to avoid:
  resham ≠ zardozi  (resham = silk thread, zardozi = metal wire)
  dabka ≠ resham    (dabka = coiled metal, resham = flat silk stitch)
  mirror ≠ sequin   (mirror = circular glass, sequin = flat plastic/metal)
  zari ≠ resham     (zari = metallic thread, resham = silk thread)
  gota ≠ zari       (gota = flat metallic RIBBON, zari = thread)

If genuinely uncertain → confidence: "uncertain", explain in new_candidate_description.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SILHOUETTE VOCABULARY — USE EXACTLY THESE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Menswear:
  "3-piece-sherwani-set"     "achkan-jacket-set"    "bandgala-suit"
  "kurta-pyjama-set"         "nehru-jacket-set"     "indo-western-jacket-set"

Womenswear:
  "lehenga-choli-dupatta"    "saree"                "anarkali-set"
  "sharara-set"              "kurta-set"            "gown"
  "coord-set"                "peplum-skirt-set"

"sherwani" alone is REJECTED. "lehenga set" alone is REJECTED.
Always be specific about components.

Return ONLY valid JSON. Start with {{ end with }}.
No markdown. No preamble.

{{
  "garment_type": "",
  "silhouette": "",
  "gender": "menswear|womenswear|unisex",
  "components": [],
  "embellishments": [
    {{
      "embellishment_id": "",
      "common_name": "",
      "component": "",
      "confidence": "confirmed|probable|uncertain",
      "mirror_details": {{
        "scatter_pattern": null,
        "mirror_size": null,
        "connecting_thread": null,
        "coverage_estimate_percent": null
      }},
      "is_new_candidate": false,
      "new_candidate_description": ""
    }}
  ],
  "embroidery_density": "all-over|heavy-front|border-only|scattered|medium|light",
  "embroidery_density_notes": "",
  "outfit_completeness": {{
    "is_set": false,
    "includes": [],
    "missing_for_complete_look": []
  }},
  "styling_dna": {{
    "aesthetic_category": "",
    "aesthetic_justification": "",
    "occasion_suitability": [],
    "occasion_not_suitable_for": [],
    "trend_position": "classic|trending|avant-garde|legacy"
  }}
}}
"""
