"""
pipeline/validators/quality_gate.py

Runs after EVERY single product extraction.
If validation fails → marks needs_manual_review: true
Logs exactly which rule failed.
Never silently passes bad data.
BLOCKS the batch if single-product test fails.
"""

import json
import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def load_quality_gates(config_path: str = None) -> list:
    """Load quality gates from config file."""
    if config_path is None:
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "config", "quality_gates.json"
        )
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _flatten_output_to_text(output: dict) -> str:
    """
    Recursively flatten the entire output dict to lowercase text
    for scanning. This catches hallucinations buried deep in nested fields.
    """
    def _recurse(obj):
        if isinstance(obj, dict):
            return " ".join(_recurse(v) for v in obj.values())
        elif isinstance(obj, list):
            return " ".join(_recurse(i) for i in obj)
        elif isinstance(obj, str):
            return obj.lower()
        else:
            return str(obj).lower()
    return _recurse(output)


def _check_caption_quality(output: dict, gate: dict) -> list:
    """Check caption-specific quality rules."""
    failures = []
    caption = output.get("caption", {})
    if not caption:
        failures.append("CAPTION MISSING: caption block is empty or null")
        return failures

    caption_text = _flatten_output_to_text(caption)

    # Check caption must mention
    for term in gate.get("caption_must_mention", []):
        if term.lower() not in caption_text:
            failures.append(
                f"CAPTION MISSING TERM: '{term}' should appear "
                f"in caption for {gate['designer_id']}"
            )

    # Check caption must not say
    for term in gate.get("caption_must_not_say", []):
        if term.lower() in caption_text:
            failures.append(
                f"CAPTION HALLUCINATION: '{term}' appeared in caption "
                f"but is wrong for {gate['designer_id']}"
            )

    # Check for leaked JSON keys in caption prose
    json_key_leaks = [
        "fabric_vocabulary", "vision_only", "text_only",
        "confirmed_techniques", "new_candidate", "db_matched",
        "embellishment_id", "fabric_id", "drape_score"
    ]
    for key in json_key_leaks:
        if key in caption_text:
            failures.append(
                f"CAPTION JSON LEAK: '{key}' appeared in caption prose — "
                f"model is leaking internal field names"
            )

    # Check banned words
    banned_words = [
        "stunning", "gorgeous", "beautiful", "perfect",
        "elegant", "exquisite", "breathtaking", "dreamy",
        "luxurious", "timeless", "effortlessly"
    ]
    for word in banned_words:
        if word in caption_text:
            failures.append(
                f"CAPTION BANNED WORD: '{word}' used — replace with "
                f"specific technical observation"
            )

    # Check caption sections exist and are non-empty
    required_sections = [
        "fabric_and_craft",
        "cultural_significance",
        "styling_context",
        "occasion_intelligence"
    ]
    for section in required_sections:
        if not caption.get(section):
            failures.append(
                f"CAPTION SECTION EMPTY: '{section}' is null or empty"
            )

    return failures


def validate_product(
    output: dict,
    designer_id: str,
    gates: list,
    is_test_run: bool = False
) -> dict:
    """
    Main validation function.
    Runs after every single product extraction.

    Args:
        output: the full extracted product dict
        designer_id: e.g. "abhinav_mishra"
        gates: loaded quality_gates list
        is_test_run: if True, prints verbose output

    Returns:
        output dict with quality_gate_passed, validation_failures added
    """
    gate = next((g for g in gates if g["designer_id"] == designer_id), None)

    if not gate:
        logger.warning(
            "No quality gate defined for designer '%s' — "
            "passing through with warning", designer_id
        )
        output["quality_gate_passed"] = None
        output["quality_gate_warning"] = (
            f"No gate defined for {designer_id} — "
            f"add to quality_gates.json before production run"
        )
        return output

    failures = []

    # ── 1. Flatten entire output to text for scanning ─────────────────────
    output_text = _flatten_output_to_text(output)

    # ── 2. Must NOT appear checks ──────────────────────────────────────────
    for banned_term in gate.get("must_not_appear", []):
        if banned_term.lower() in output_text:
            failures.append(
                f"HALLUCINATION: '{banned_term}' appeared but is "
                f"not expected for {designer_id}"
            )

    # ── 3. Must appear checks ──────────────────────────────────────────────
    for required_term in gate.get("must_appear", []):
        if required_term.lower() not in output_text:
            failures.append(
                f"MISSING: '{required_term}' should appear for "
                f"{designer_id} but was not found anywhere in output"
            )

    # ── 4. Aesthetic category check ───────────────────────────────────────
    expected_aesthetic = gate.get("expected_aesthetic", "")
    actual_aesthetic = output.get("aesthetic_category", "") or \
                       output.get("styling_dna", {}).get("aesthetic_category", "")

    if expected_aesthetic and actual_aesthetic:
        if expected_aesthetic.lower() not in actual_aesthetic.lower():
            failures.append(
                f"AESTHETIC MISMATCH: expected '{expected_aesthetic}' "
                f"but got '{actual_aesthetic}'"
            )

    # ── 5. Rimzim Dadu / Avant-garde candidate check ──────────────────────
    if gate.get("must_appear_in_candidates"):
        candidates = output.get("new_fabric_candidates", [])
        if not candidates:
            failures.append(
                f"MISSING CANDIDATES: {designer_id} should always produce "
                f"new_fabric_candidates — got empty list. "
                f"This designer's fabrics are not in the standard DB."
            )

    # ── 6. Gender check ───────────────────────────────────────────────────
    primary_gender = gate.get("primary_gender")
    if primary_gender:
        actual_gender = output.get("gender", "")
        if actual_gender and actual_gender != primary_gender:
            failures.append(
                f"GENDER MISMATCH: {designer_id} is "
                f"primarily {primary_gender} "
                f"but got '{actual_gender}' — "
                f"check product or gender detection logic"
            )

    # ── 7. Caption quality checks ─────────────────────────────────────────
    caption_failures = _check_caption_quality(output, gate)
    failures.extend(caption_failures)

    # ── 8. Fabric specificity check ───────────────────────────────────────
    # Reject vague fabric terms that should have been caught
    vague_fabric_terms = [
        "special silk", "premium fabric", "special fabric",
        "luxury fabric", "designer fabric", "embroidery"  # embroidery alone
    ]
    fabric_vocab = output.get("fabric_vocabulary", {})
    confirmed_fabrics = fabric_vocab.get("confirmed", [])

    for fabric_entry in confirmed_fabrics:
        # Handle both string and dict formats
        fabric_name = ""
        if isinstance(fabric_entry, str):
            fabric_name = fabric_entry.lower()
        elif isinstance(fabric_entry, dict):
            fabric_name = fabric_entry.get("fabric_id", "").lower()

        for vague in vague_fabric_terms:
            if vague in fabric_name:
                failures.append(
                    f"VAGUE FABRIC IN CONFIRMED: '{fabric_entry}' is a "
                    f"marketing term not a fabric name — should be in "
                    f"new_fabric_candidates, not confirmed"
                )

    # ── 9. Apply results ──────────────────────────────────────────────────
    if failures:
        output["needs_manual_review"] = True
        output["validation_failures"] = failures
        output["quality_gate_passed"] = False

        logger.error(
            "❌ QUALITY GATE FAILED for %s — %d failures:",
            designer_id, len(failures)
        )
        for f in failures:
            logger.error("   → %s", f)

        if is_test_run:
            print(f"\n❌ QUALITY GATE FAILED — {designer_id}")
            print(f"   {len(failures)} failure(s) found:\n")
            for f in failures:
                print(f"   → {f}")
            print()
    else:
        output["quality_gate_passed"] = True
        logger.info("✅ Quality gate passed for %s", designer_id)

        if is_test_run:
            print(f"\n✅ QUALITY GATE PASSED — {designer_id}\n")

    return output


def save_failed_test(output: dict, designer_id: str, output_dir: str = "pipeline/output/failed_tests"):
    """Save a failed single-product test for debugging."""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"{designer_id}_failed_test.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False, default=str)
    logger.info("Saved failed test output to %s", path)
    return path


def generate_batch_quality_report(
    products: list,
    designer_id: str,
    gates: list
) -> dict:
    """
    Run quality validation across an entire batch.
    Returns summary report.
    """
    results = {
        "designer_id": designer_id,
        "total": len(products),
        "passed": 0,
        "failed": 0,
        "failure_breakdown": {},
        "products_needing_review": []
    }

    for product in products:
        validated = validate_product(product, designer_id, gates)
        if validated.get("quality_gate_passed"):
            results["passed"] += 1
        else:
            results["failed"] += 1
            product_id = product.get("source_id", "unknown")
            results["products_needing_review"].append(product_id)

            # Count failure types
            for failure in validated.get("validation_failures", []):
                failure_type = failure.split(":")[0]
                results["failure_breakdown"][failure_type] = \
                    results["failure_breakdown"].get(failure_type, 0) + 1

    results["pass_rate"] = (
        f"{(results['passed'] / results['total'] * 100):.1f}%"
        if results["total"] > 0 else "0%"
    )

    return results
