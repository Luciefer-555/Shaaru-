"""
pipeline/run_pipeline.py

Main entry point for the Shaaru Fashion Knowledge Pipeline.
Config-driven. Single-product test gate enforced before every batch.
Nothing runs without passing the quality gate first.

Usage:
    # Single product test only (mandatory before batch):
    python run_pipeline.py --source abhinav_mishra --mode product --test-only

    # Full batch (auto-runs test first, blocks if test fails):
    python run_pipeline.py --source abhinav_mishra --mode product --limit 10

    # All active designers (runs test for each before batch):
    python run_pipeline.py --mode product --all --limit 10

    # Force skip test gate (DANGEROUS — only use in dev):
    python run_pipeline.py --source abhinav_mishra --mode product --skip-gate
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# ── Setup logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("pipeline/output/pipeline.log", encoding="utf-8"),
    ]
)
logger = logging.getLogger("run_pipeline")

# ── Local imports ─────────────────────────────────────────────────────────────
from pipeline.scrapers.shopify_scraper import ShopifyScraper
from pipeline.scrapers.custom_scraper import CustomScraper
from pipeline.extractors.tailor_engine import analyze_garment_deep
from pipeline.validators.quality_gate import (
    load_quality_gates,
    validate_product,
    save_failed_test,
    generate_batch_quality_report,
)
from pipeline.db.db_loader import load_all_references
from pipeline.db.inserter import save_to_review_folder
from pipeline.deduplicator.dedup import is_duplicate, add_to_dedup_index


# ── Config paths ──────────────────────────────────────────────────────────────
DESIGNERS_CONFIG = "pipeline/config/designers.json"
QUALITY_GATES_CONFIG = "pipeline/config/quality_gates.json"
OUTPUT_DIR = "pipeline/output/review"
CHECKPOINT_DIR = "pipeline/output/checkpoints"
COST_LOG_PATH = "pipeline/output/cost_log.json"
FAILED_TESTS_DIR = "pipeline/output/failed_tests"


def load_designers(source_filter: str = None) -> list:
    with open(DESIGNERS_CONFIG, "r", encoding="utf-8") as f:
        designers = json.load(f)

    if source_filter:
        designers = [d for d in designers if d["id"] == source_filter]
        if not designers:
            raise ValueError(
                f"Designer '{source_filter}' not found in {DESIGNERS_CONFIG}"
            )
    else:
        designers = [d for d in designers if d.get("active", False)]

    return designers


def load_checkpoint(designer_id: str) -> int:
    """Returns the index of the last successfully processed product."""
    path = os.path.join(CHECKPOINT_DIR, f"{designer_id}_checkpoint.json")
    if os.path.exists(path):
        with open(path, "r") as f:
            data = json.load(f)
            return data.get("last_completed_index", -1)
    return -1


def save_checkpoint(designer_id: str, index: int):
    """Save progress checkpoint so pipeline can resume if interrupted."""
    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    path = os.path.join(CHECKPOINT_DIR, f"{designer_id}_checkpoint.json")
    with open(path, "w") as f:
        json.dump({
            "designer_id": designer_id,
            "last_completed_index": index,
            "saved_at": datetime.utcnow().isoformat()
        }, f, indent=2)


def append_cost_log(product_cost: dict):
    """Append per-product cost to global cost log."""
    os.makedirs(os.path.dirname(COST_LOG_PATH), exist_ok=True)
    costs = []
    if os.path.exists(COST_LOG_PATH):
        with open(COST_LOG_PATH, "r") as f:
            costs = json.load(f)
    costs.append(product_cost)
    with open(COST_LOG_PATH, "w") as f:
        json.dump(costs, f, indent=2)


async def process_single_product(
    product: dict,
    designer_config: dict,
    db_refs: dict,
    gates: list,
    is_test: bool = False
) -> dict:
    """
    Process one product through the full pipeline:
    scrape → vision → text → reconcile → caption → validate

    Returns the validated output dict.
    """
    product_title = product.get("title", "Unknown")
    designer_id = designer_config["id"]

    logger.info(
        "Processing: %s — %s",
        designer_id, product_title
    )

    try:
        # ── Run full extraction ───────────────────────────────────────────
        output, cost_log = await analyze_garment_deep(
            product=product,
            designer_config=designer_config,
            db_refs=db_refs,
            gates=gates,
        )

        # ── Append cost ───────────────────────────────────────────────────
        cost_log["product_id"] = product.get("id", "")
        cost_log["title"] = product_title
        cost_log["designer_id"] = designer_id
        cost_log["timestamp"] = datetime.utcnow().isoformat()
        append_cost_log(cost_log)

        # ── Run quality gate ──────────────────────────────────────────────
        output = validate_product(output, designer_id, gates, is_test_run=is_test)

        return output

    except Exception as e:
        logger.error(
            "EXTRACTION FAILED for %s — %s: %s",
            designer_id, product_title, str(e)
        )
        return {
            "source_id": product.get("id", ""),
            "title": product_title,
            "designer": designer_config["name"],
            "needs_manual_review": True,
            "quality_gate_passed": False,
            "validation_failures": [f"EXTRACTION ERROR: {str(e)}"],
            "caption": {}
        }


async def run_single_product_test(
    designer_config: dict,
    db_refs: dict,
    gates: list,
    scraper
) -> tuple[bool, dict]:
    """
    MANDATORY test that runs before every batch.
    Fetches the first product and validates it.

    Returns:
        (passed: bool, output: dict)
    """
    designer_id = designer_config["id"]
    designer_name = designer_config["name"]

    print(f"\n{'='*60}")
    print(f"  MANDATORY SINGLE-PRODUCT TEST: {designer_name}")
    print(f"{'='*60}")
    print("  Running before batch. Batch will be BLOCKED if this fails.\n")

    # Fetch first product only
    products = []
    async for product in scraper.scrape(limit=1):
        products.append(product)
        break

    if not products:
        logger.error(
            "⛔ TEST BLOCKED: Could not scrape any products from %s",
            designer_name
        )
        return False, {"error": "scraping_failed"}

    test_product = products[0]
    print(f"  Test product: {test_product.get('title', 'Unknown')}")
    print(f"  URL: {test_product.get('source_url', '')}\n")

    # Process it
    output = await process_single_product(
        product=test_product,
        designer_config=designer_config,
        db_refs=db_refs,
        gates=gates,
        is_test=True
    )

    passed = output.get("quality_gate_passed", False)

    if not passed:
        print(f"\n⛔ BATCH BLOCKED FOR {designer_name.upper()}")
        print("  Fix the failures above before running the batch.")
        print("  Saving failed test output for debugging...\n")
        save_failed_test(output, designer_id, FAILED_TESTS_DIR)
        return False, output

    print(f"✅ TEST PASSED — Proceeding to batch for {designer_name}\n")
    return True, output


async def run_designer_batch(
    designer_config: dict,
    db_refs: dict,
    gates: list,
    limit: int = 10,
    skip_gate: bool = False,
    test_only: bool = False,
    balance_genders: bool = True
) -> dict:
    """
    Full pipeline for one designer.

    Flow:
        1. Single product test (mandatory unless skip_gate=True)
        2. If test passes → run batch
        3. Save each batch of 25 to output/review/
        4. Checkpoint every product

    Returns summary dict.
    """
    designer_id = designer_config["id"]
    designer_name = designer_config["name"]
    platform = designer_config.get("platform", "shopify")

    # ── Initialize scraper ────────────────────────────────────────────────
    if platform == "shopify":
        scraper = ShopifyScraper(
            designer_config=designer_config,
            balance_genders=balance_genders
        )
    else:
        scraper = CustomScraper(
            designer_config=designer_config,
            balance_genders=balance_genders
        )

    summary = {
        "designer_id": designer_id,
        "designer_name": designer_name,
        "started_at": datetime.utcnow().isoformat(),
        "total_scraped": 0,
        "total_processed": 0,
        "quality_gate_passed": 0,
        "quality_gate_failed": 0,
        "needs_manual_review": 0,
        "new_fabric_candidates": [],
        "new_embellishment_candidates": [],
        "new_pattern_candidates": [],
        "aesthetic_distribution": {},
        "blocked_reason": None,
        "completed_at": None
    }

    # ── Step 1: Mandatory single-product test ─────────────────────────────
    if not skip_gate:
        test_passed, test_output = await run_single_product_test(
            designer_config=designer_config,
            db_refs=db_refs,
            gates=gates,
            scraper=scraper
        )

        if not test_passed:
            summary["blocked_reason"] = "single_product_test_failed"
            summary["test_output"] = test_output
            return summary

        if test_only:
            summary["test_output"] = test_output
            summary["test_passed"] = True
            return summary
    else:
        logger.warning(
            "⚠️  Quality gate SKIPPED for %s — skip_gate=True",
            designer_name
        )

    # ── Step 2: Full batch ────────────────────────────────────────────────
    logger.info(
        "Starting batch for %s — limit: %s",
        designer_name, limit or "none"
    )

    checkpoint = load_checkpoint(designer_id)
    all_products = []
    batch = []
    batch_number = 1
    product_index = 0

    async for product in scraper.scrape(limit=limit):

        # Skip already processed (resume from checkpoint)
        if product_index <= checkpoint:
            product_index += 1
            continue

        summary["total_scraped"] += 1

        # ── Check deduplication ───────────────────────────────────────────
        if is_duplicate(product, designer_id):
            logger.info(
                "Skipping duplicate: %s", product.get("title", "")
            )
            product_index += 1
            continue

        # ── Process product ───────────────────────────────────────────────
        output = await process_single_product(
            product=product,
            designer_config=designer_config,
            db_refs=db_refs,
            gates=gates,
        )

        summary["total_processed"] += 1

        # ── Update summary stats ──────────────────────────────────────────
        if output.get("quality_gate_passed"):
            summary["quality_gate_passed"] += 1
        else:
            summary["quality_gate_failed"] += 1

        if output.get("needs_manual_review"):
            summary["needs_manual_review"] += 1

        # Collect new candidates
        for c in output.get("new_fabric_candidates", []):
            if c not in summary["new_fabric_candidates"]:
                summary["new_fabric_candidates"].append(c)

        for c in output.get("new_embellishment_candidates", []):
            if c not in summary["new_embellishment_candidates"]:
                summary["new_embellishment_candidates"].append(c)

        for c in output.get("new_pattern_candidates", []):
            if c not in summary["new_pattern_candidates"]:
                summary["new_pattern_candidates"].append(c)

        # Aesthetic distribution
        aesthetic = output.get("aesthetic_category", "Unknown")
        summary["aesthetic_distribution"][aesthetic] = \
            summary["aesthetic_distribution"].get(aesthetic, 0) + 1

        # Add to dedup index
        add_to_dedup_index(output, designer_id)

        batch.append(output)
        all_products.append(output)

        # ── Save batch every 25 products ──────────────────────────────────
        if len(batch) >= 25:
            _save_batch(batch, designer_id, batch_number)
            batch_number += 1
            batch = []

        # ── Checkpoint every product ──────────────────────────────────────
        save_checkpoint(designer_id, product_index)
        product_index += 1

        # ── Crawl delay ───────────────────────────────────────────────────
        await asyncio.sleep(2)

    # ── Save final partial batch ──────────────────────────────────────────
    if batch:
        _save_batch(batch, designer_id, batch_number)

    # ── Generate quality report ───────────────────────────────────────────
    quality_report = generate_batch_quality_report(all_products, designer_id, gates)
    summary["quality_report"] = quality_report
    summary["completed_at"] = datetime.utcnow().isoformat()

    # ── Save complete summary ─────────────────────────────────────────────
    summary_path = os.path.join(
        OUTPUT_DIR, f"{designer_id}_COMPLETE_summary.json"
    )
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False, default=str)

    logger.info(
        "✅ COMPLETE: %s — %d products processed, %d passed gate, %d failed",
        designer_name,
        summary["total_processed"],
        summary["quality_gate_passed"],
        summary["quality_gate_failed"]
    )

    return summary


def _save_batch(products: list, designer_id: str, batch_number: int):
    """Save a batch of products to the review folder."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    path = os.path.join(
        OUTPUT_DIR,
        f"{designer_id}_batch_{batch_number}.json"
    )
    with open(path, "w", encoding="utf-8") as f:
        json.dump(products, f, indent=2, ensure_ascii=False, default=str)
    logger.info(
        "Saved batch %d for %s → %s (%d products)",
        batch_number, designer_id, path, len(products)
    )


async def main():
    parser = argparse.ArgumentParser(
        description="Shaaru Fashion Knowledge Pipeline"
    )
    parser.add_argument(
        "--source",
        type=str,
        help="Designer ID to run (e.g. abhinav_mishra). Omit to run all active."
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=["product", "editorial"],
        default="product",
        help="Pipeline mode"
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Max products per designer. 0 = no limit."
    )
    parser.add_argument(
        "--test-only",
        action="store_true",
        help="Run single-product test only. Do not proceed to batch."
    )
    parser.add_argument(
        "--skip-gate",
        action="store_true",
        help="DANGEROUS: Skip the quality gate. Dev use only."
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run all active designers from designers.json"
    )
    parser.add_argument(
        "--balance-genders",
        action="store_true",
        default=True,
        help="Enforce 50/50 men/womenswear balance"
    )

    args = parser.parse_args()

    if args.skip_gate:
        logger.warning(
            "⚠️  WARNING: Quality gate disabled. "
            "This may produce hallucinated outputs."
        )

    # ── Load configs ──────────────────────────────────────────────────────
    designers = load_designers(args.source if not args.all else None)
    gates = load_quality_gates(QUALITY_GATES_CONFIG)
    db_refs = load_all_references(
        mongo_uri=os.environ["MONGODB_URI"],
        neo4j_uri=os.environ["NEO4J_URI"],
        neo4j_user=os.environ["NEO4J_USER"],
        neo4j_password=os.environ["NEO4J_PASSWORD"]
    )

    if not designers:
        logger.error("No active designers found. Check designers.json")
        sys.exit(1)

    limit = args.limit if args.limit > 0 else None

    logger.info(
        "Starting pipeline — %d designer(s), limit: %s, test_only: %s",
        len(designers), limit or "none", args.test_only
    )

    all_summaries = []
    blocked_designers = []

    # ── Run each designer ─────────────────────────────────────────────────
    for designer_config in designers:
        designer_id = designer_config["id"]

        print(f"\n{'#'*60}")
        print(f"  DESIGNER: {designer_config['name']}")
        print(f"  Platform: {designer_config.get('platform', 'shopify')}")
        print(f"  Aesthetic: {designer_config.get('aesthetic_hint', '')}")
        print(f"{'#'*60}\n")

        summary = await run_designer_batch(
            designer_config=designer_config,
            db_refs=db_refs,
            gates=gates,
            limit=limit,
            skip_gate=args.skip_gate,
            test_only=args.test_only,
            balance_genders=args.balance_genders,
        )

        all_summaries.append(summary)

        if summary.get("blocked_reason"):
            blocked_designers.append({
                "designer_id": designer_id,
                "reason": summary["blocked_reason"]
            })
            logger.warning(
                "⛔ %s was BLOCKED: %s",
                designer_config["name"],
                summary["blocked_reason"]
            )

    # ── Final report ──────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("  PIPELINE COMPLETE")
    print(f"{'='*60}")

    total_products = sum(s.get("total_processed", 0) for s in all_summaries)
    total_passed = sum(s.get("quality_gate_passed", 0) for s in all_summaries)
    total_failed = sum(s.get("quality_gate_failed", 0) for s in all_summaries)

    print(f"\n  Total products processed:  {total_products}")
    print(f"  Quality gate passed:       {total_passed}")
    print(f"  Quality gate failed:       {total_failed}")
    print(f"  Designers blocked:         {len(blocked_designers)}")

    if blocked_designers:
        print("\n  BLOCKED DESIGNERS:")
        for b in blocked_designers:
            print(f"    → {b['designer_id']}: {b['reason']}")

    print(f"\n  All outputs in: {OUTPUT_DIR}/")
    print(f"  Cost log: {COST_LOG_PATH}")
    print()

    # Save master summary
    master_path = os.path.join(OUTPUT_DIR, "MASTER_SUMMARY.json")
    with open(master_path, "w", encoding="utf-8") as f:
        json.dump({
            "run_completed_at": datetime.utcnow().isoformat(),
            "total_products": total_products,
            "total_passed": total_passed,
            "total_failed": total_failed,
            "blocked_designers": blocked_designers,
            "designer_summaries": all_summaries
        }, f, indent=2, ensure_ascii=False, default=str)

    logger.info("Master summary saved to %s", master_path)


if __name__ == "__main__":
    asyncio.run(main())
